import Foundation

@MainActor
final class ScreenshotStore: ObservableObject {
    @Published private(set) var screenshots: [ScreenshotRecord] = []

    private let fileURL: URL

    init() {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        self.fileURL = dir.appendingPathComponent("screenshots.json")
        load()
    }

    func add(_ record: ScreenshotRecord) {
        screenshots.insert(record, at: 0)
        save()
    }

    func delete(_ record: ScreenshotRecord) {
        screenshots.removeAll { $0.id == record.id }
        save()
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? JSONDecoder().decode([ScreenshotRecord].self, from: data) else {
            screenshots = []
            return
        }
        screenshots = decoded.sorted { $0.createdAt > $1.createdAt }
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(screenshots) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }
}
