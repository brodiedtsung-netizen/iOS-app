import SwiftUI

struct ArchiveView: View {
    @EnvironmentObject private var store: ScreenshotStore

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: 14) {
                    if store.screenshots.isEmpty {
                        ContentUnavailableView(
                            "No Screenshots",
                            systemImage: "photo.on.rectangle.angled",
                            description: Text("Trigger a capture from the Home tab.")
                        )
                        .padding(.top, 80)
                    } else {
                        ForEach(store.screenshots) { shot in
                            VStack(alignment: .leading, spacing: 10) {
                                Image(shot.imageName)
                                    .resizable()
                                    .scaledToFill()
                                    .aspectRatio(16/9, contentMode: .fit)
                                    .clipShape(RoundedRectangle(cornerRadius: 14))

                                HStack {
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text("Capture")
                                            .font(.headline)
                                        Text(shot.createdAt.formatted(date: .abbreviated, time: .standard))
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Button(role: .destructive) {
                                        store.delete(shot)
                                    } label: {
                                        Image(systemName: "trash")
                                    }
                                }
                            }
                            .padding()
                            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Archive")
        }
    }
}
