import Foundation

@MainActor
final class MockPiService: ObservableObject {
    @Published var simulationEnabled = true
    @Published var online = true
    @Published var networkDelay = 1.0
    @Published var storageGB = 32.0
    @Published var simulateFailure = false
    @Published var randomStats = true
    @Published var status = PiStatus()
    @Published var captureStage = ""
    @Published var isCapturing = false
    @Published var errorMessage = ""

    func refreshStatus() async {
        guard simulationEnabled, online, !simulateFailure else {
            status.online = false
            return
        }

        try? await Task.sleep(for: .milliseconds(250))

        status.online = true
        status.ip = "192.168.1.42"
        if randomStats {
            status.cpu = Int.random(in: 20...78)
            status.ram = Int.random(in: 35...76)
            status.temperature = Int.random(in: 39...58)
            status.ping = Int.random(in: 4...26)
            let used = Double(Int.random(in: 6...18))
            status.storageTotal = storageGB
            status.storageFree = max(1, storageGB - used)
        } else {
            status.cpu = 43
            status.ram = 61
            status.temperature = 47
            status.ping = 7
            status.storageTotal = storageGB
            status.storageFree = min(18.7, storageGB)
        }
        status.lastSync = .now
    }

    func capture() async throws -> ScreenshotRecord {
        guard simulationEnabled else {
            throw SimulatorError.message("Simulation Mode is off.")
        }
        guard online, !simulateFailure else {
            throw SimulatorError.message("Connection failed. The simulated Pi is offline.")
        }

        isCapturing = true
        errorMessage = ""
        defer { isCapturing = false }

        let slice = max(0.2, networkDelay / 3)

        captureStage = "Sending request..."
        try await Task.sleep(for: .seconds(slice))

        captureStage = "Pi capturing screen..."
        try await Task.sleep(for: .seconds(slice))

        captureStage = "Downloading screenshot..."
        try await Task.sleep(for: .seconds(slice))

        let record = ScreenshotRecord(sampleIndex: Int.random(in: 1...6))
        captureStage = "Saved to Archive ✓"

        await refreshStatus()

        try? await Task.sleep(for: .milliseconds(900))
        captureStage = ""
        return record
    }
}

enum SimulatorError: LocalizedError {
    case message(String)

    var errorDescription: String? {
        switch self {
        case .message(let text): return text
        }
    }
}
