import SwiftUI

@main
struct PiViewerApp: App {
    @StateObject private var store = ScreenshotStore()
    @StateObject private var simulator = MockPiService()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environmentObject(simulator)
                .preferredColorScheme(.dark)
        }
    }
}
