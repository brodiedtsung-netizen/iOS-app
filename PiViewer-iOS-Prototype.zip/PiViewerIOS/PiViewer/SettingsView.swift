import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var simulator: MockPiService

    var body: some View {
        NavigationStack {
            Form {
                Section("Simulation Mode") {
                    Toggle("Simulation Enabled", isOn: $simulator.simulationEnabled)
                    Toggle("Pi Connection Online", isOn: $simulator.online)
                    Toggle("Simulate Connection Failure", isOn: $simulator.simulateFailure)
                    Toggle("Generate Random Stats", isOn: $simulator.randomStats)
                }

                Section("Fake Raspberry Pi") {
                    Picker("Network Delay", selection: $simulator.networkDelay) {
                        Text("0.25 seconds").tag(0.25)
                        Text("0.5 seconds").tag(0.5)
                        Text("1 second").tag(1.0)
                        Text("2 seconds").tag(2.0)
                        Text("4 seconds").tag(4.0)
                    }

                    Picker("Fake Storage", selection: $simulator.storageGB) {
                        Text("16 GB").tag(16.0)
                        Text("32 GB").tag(32.0)
                        Text("64 GB").tag(64.0)
                        Text("128 GB").tag(128.0)
                    }

                    LabeledContent("Fake IP", value: "192.168.1.42")
                }

                Section {
                    Text("Prototype 1 runs fully on the iPhone. No Raspberry Pi, Ubuntu computer, SSH server or API is required.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Simulation")
        }
    }
}
