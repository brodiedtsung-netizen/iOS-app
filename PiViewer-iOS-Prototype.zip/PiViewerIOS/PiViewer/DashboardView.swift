import SwiftUI

struct DashboardView: View {
    @EnvironmentObject private var store: ScreenshotStore
    @EnvironmentObject private var simulator: MockPiService

    var latest: ScreenshotRecord? { store.screenshots.first }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("DESKTOP SCREENSHOT VIEWER")
                            .font(.caption.bold())
                            .foregroundStyle(.green)
                        Text("Command Center")
                            .font(.largeTitle.bold())
                    }

                    VStack(spacing: 14) {
                        HStack {
                            VStack(alignment: .leading) {
                                Text("Raspberry Pi")
                                    .font(.headline)
                                Text(simulator.status.ip)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text(simulator.status.online ? "● ONLINE" : "● OFFLINE")
                                .font(.caption.bold())
                                .foregroundStyle(simulator.status.online ? .green : .red)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 7)
                                .background(.thinMaterial, in: Capsule())
                        }

                        Group {
                            if let latest {
                                Image(latest.imageName)
                                    .resizable()
                                    .scaledToFill()
                            } else {
                                ZStack {
                                    Rectangle().fill(Color.black.opacity(0.25))
                                    Text("No captures yet")
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                        .aspectRatio(16/9, contentMode: .fit)
                        .clipShape(RoundedRectangle(cornerRadius: 16))

                        Button {
                            Task {
                                do {
                                    let shot = try await simulator.capture()
                                    store.add(shot)
                                } catch {
                                    simulator.errorMessage = error.localizedDescription
                                }
                            }
                        } label: {
                            HStack {
                                if simulator.isCapturing {
                                    ProgressView().tint(.black)
                                }
                                Text(simulator.isCapturing ? "CAPTURING..." : "⚡ TRIGGER CAPTURE")
                                    .fontWeight(.black)
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .foregroundStyle(.black)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                        }
                        .disabled(simulator.isCapturing)

                        if !simulator.captureStage.isEmpty {
                            Text(simulator.captureStage)
                                .font(.subheadline.bold())
                                .foregroundStyle(.green)
                        }

                        if !simulator.errorMessage.isEmpty {
                            Text(simulator.errorMessage)
                                .font(.subheadline.bold())
                                .foregroundStyle(.red)
                        }
                    }
                    .padding()
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 22))

                    Text("System Health")
                        .font(.title2.bold())

                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        StatCard(title: "CPU", value: "\(simulator.status.cpu)%", progress: Double(simulator.status.cpu)/100)
                        StatCard(title: "RAM", value: "\(simulator.status.ram)%", progress: Double(simulator.status.ram)/100)
                        StatCard(title: "TEMP", value: "\(simulator.status.temperature)°C")
                        StatCard(title: "PING", value: "\(simulator.status.ping) ms")
                    }

                    StatCard(
                        title: "STORAGE",
                        value: String(format: "%.1f GB FREE / %.0f GB", simulator.status.storageFree, simulator.status.storageTotal),
                        progress: 1 - simulator.status.storageFree / simulator.status.storageTotal
                    )

                    Text("Last sync: \(simulator.status.lastSync.formatted(date: .abbreviated, time: .standard))")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                }
                .padding()
            }
            .task {
                await simulator.refreshStatus()
            }
            .navigationBarHidden(true)
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    var progress: Double? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Text(value)
                    .font(.headline.bold())
            }
            if let progress {
                ProgressView(value: max(0, min(progress, 1)))
                    .tint(.green)
            }
        }
        .padding()
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}
