import Foundation

struct ScreenshotRecord: Identifiable, Codable, Equatable {
    let id: UUID
    let sampleIndex: Int
    let createdAt: Date

    init(id: UUID = UUID(), sampleIndex: Int, createdAt: Date = .now) {
        self.id = id
        self.sampleIndex = sampleIndex
        self.createdAt = createdAt
    }

    var imageName: String { "sample\(sampleIndex)" }
}

struct PiStatus {
    var online = true
    var ip = "192.168.1.42"
    var cpu = 43
    var ram = 61
    var temperature = 47
    var storageFree = 18.7
    var storageTotal = 32.0
    var ping = 7
    var lastSync = Date()
}
