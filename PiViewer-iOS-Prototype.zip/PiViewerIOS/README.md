# Pi Viewer iOS Prototype

This is the native iPhone version of the Raspberry Pi screenshot viewer prototype.

## Requirements
- A Mac with Xcode
- iOS 17 or newer for the included project settings
- No Raspberry Pi, Ubuntu computer, server, SSH connection or API required for Prototype 1

## Run
1. Unzip this folder on your Mac.
2. Open `PiViewer.xcodeproj`.
3. Pick an iPhone Simulator from the device menu.
4. Press Run.
5. To put it on your real iPhone, sign into Xcode with your Apple ID, choose your development team under Signing & Capabilities, select your iPhone, and press Run.

## Included
- Native SwiftUI interface
- Fake Raspberry Pi online/offline state
- Fake IP, CPU, RAM, temperature, storage and ping
- Fake network delay
- Connection failure simulation
- Fake screenshot capture stages
- 6 sample desktop screenshots
- Persistent local archive using JSON in the iPhone Documents directory
- Delete screenshot
- Settings controls

Prototype 2 can replace `MockPiService.swift` with a real local-network Raspberry Pi service.
